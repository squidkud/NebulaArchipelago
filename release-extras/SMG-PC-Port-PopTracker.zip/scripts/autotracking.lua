-- Archipelago auto-tracking: items received and locations checked, straight from the server.
CUR_INDEX = -1

local function reset()
    CUR_INDEX = -1
    for _, mapped in pairs(ITEM_MAPPING) do
        local obj = Tracker:FindObjectForCode(mapped[1])
        if obj then
            if mapped[2] == "count" then
                obj.AcquiredCount = 0
            else
                obj.Active = false
            end
        end
    end
    for _, path in pairs(LOCATION_MAPPING) do
        local obj = Tracker:FindObjectForCode(path)
        if obj then
            obj.AvailableChestCount = obj.ChestCount
        end
    end
end

function onClear(slot_data)
    reset()
end

function onItem(index, item_id, item_name, player_number)
    if index <= CUR_INDEX then
        return
    end
    CUR_INDEX = index
    local mapped = ITEM_MAPPING[item_id]
    if not mapped then
        return
    end
    local obj = Tracker:FindObjectForCode(mapped[1])
    if not obj then
        return
    end
    if mapped[2] == "count" then
        obj.AcquiredCount = obj.AcquiredCount + 1
    else
        obj.Active = true
    end
end

function onLocation(location_id, location_name)
    local path = LOCATION_MAPPING[location_id]
    if not path then
        return
    end
    local obj = Tracker:FindObjectForCode(path)
    if obj then
        obj.AvailableChestCount = obj.AvailableChestCount - 1
    end
end

Archipelago:AddClearHandler("smg clear", onClear)
Archipelago:AddItemHandler("smg item", onItem)
Archipelago:AddLocationHandler("smg location", onLocation)
